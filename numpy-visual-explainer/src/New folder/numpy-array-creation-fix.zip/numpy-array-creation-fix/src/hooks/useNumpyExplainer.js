import { useState } from "react";

import numpyModules from "../data/numpyCurriculum";
import moduleContent from "../data/moduleContent";
import { getArrayMetrics } from "../core/arrayEngine";
import { buildDynamicCode } from "../features/numpyCode";
import conceptData from "../features/conceptData";
import { parseAndValidateArray } from "../features/arrayValidation";
import {
  generateArray,
  buildArrayCreationCode,
} from "../features/arrayCreation";

const DEFAULT_ARRAY = [
  [1, 2, 3],
  [4, 5, 6],
];

const DEFAULT_ARRAY_INPUT = "[[1, 2, 3], [4, 5, 6]]";

const DEFAULT_CREATION_PARAMS = {
  source: DEFAULT_ARRAY_INPUT,
  shape: "2, 3",
  fillValue: "7",
  start: "0",
  stop: "10",
  step: "1",
  count: "5",
  size: "3",
  values: "1, 2, 3",
  low: "0",
  high: "10",
  loc: "0",
  scale: "1",
};

function getModuleVisualMode(moduleName) {
  return moduleName === "Indexing & Slicing"
    ? "indexing"
    : "shape";
}

export default function useNumpyExplainer() {
  const [activeModule, setActiveModule] = useState(0);
  const [selectedCell, setSelectedCell] = useState(null);
  const [visualMode, setVisualMode] = useState("shape");
  const [array, setArray] = useState(DEFAULT_ARRAY);
  const [arrayInput, setArrayInput] = useState(DEFAULT_ARRAY_INPUT);
  const [arrayError, setArrayError] = useState("");

  const [creationFunction, setCreationFunction] = useState("np.array");
  const [creationParams, setCreationParams] = useState(
    DEFAULT_CREATION_PARAMS
  );
  const [creationError, setCreationError] = useState("");

  const currentModule = numpyModules[activeModule];
  const currentContent = moduleContent[currentModule.name];
  const metrics = getArrayMetrics(array);

  const dynamicCode =
    currentModule.name === "Array Creation"
      ? buildArrayCreationCode(creationFunction, creationParams)
      : buildDynamicCode(currentModule.name, array);

  const activeConcept =
    conceptData[visualMode] ?? conceptData.shape;

  const handleModuleChange = (index) => {
    const module = numpyModules[index];

    setActiveModule(index);
    setSelectedCell(null);
    setArrayError("");
    setCreationError("");
    setVisualMode(getModuleVisualMode(module.name));
  };

  const handleConceptClick = (concept) => {
    setVisualMode(concept);
  };

  const handleCellClick = (cell) => {
    setSelectedCell(cell);
  };

  const handleApplyArray = () => {
    try {
      const parsedArray = parseAndValidateArray(arrayInput);

      setArray(parsedArray);
      setSelectedCell(null);
      setArrayError("");
    } catch (error) {
      setArrayError(error.message || "Invalid array.");
    }
  };

  const handleCreationFunctionChange = (functionName) => {
    setCreationFunction(functionName);
    setCreationError("");
  };

  const handleCreationParamChange = (name, value) => {
    setCreationParams((previous) => ({
      ...previous,
      [name]: value,
    }));
    setCreationError("");
  };

  const handleGenerateArray = () => {
    try {
      const generatedArray = generateArray(
        creationFunction,
        creationParams
      );

      setArray(generatedArray);
      setArrayInput(JSON.stringify(generatedArray));
      setSelectedCell(null);
      setArrayError("");
      setCreationError("");
    } catch (error) {
      setCreationError(
        error.message || "Unable to generate array."
      );
    }
  };

  return {
    activeModule,
    currentModule,
    currentContent,
    selectedCell,
    visualMode,
    array,
    arrayInput,
    arrayError,
    metrics,
    dynamicCode,
    activeConcept,

    creationFunction,
    creationParams,
    creationError,

    setArrayInput,
    handleModuleChange,
    handleConceptClick,
    handleCellClick,
    handleApplyArray,

    handleCreationFunctionChange,
    handleCreationParamChange,
    handleGenerateArray,
  };
}

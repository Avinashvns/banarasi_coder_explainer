export const ARRAY_CREATION_FUNCTIONS = [
  { key: "np.array", label: "np.array()" },
  { key: "np.zeros", label: "np.zeros()" },
  { key: "np.ones", label: "np.ones()" },
  { key: "np.full", label: "np.full()" },
  { key: "np.empty", label: "np.empty()" },
  { key: "np.arange", label: "np.arange()" },
  { key: "np.linspace", label: "np.linspace()" },
  { key: "np.eye", label: "np.eye()" },
  { key: "np.identity", label: "np.identity()" },
  { key: "np.diag", label: "np.diag()" },
  { key: "np.random.random", label: "np.random.random()" },
  { key: "np.random.rand", label: "np.random.rand()" },
  { key: "np.random.randn", label: "np.random.randn()" },
  { key: "np.random.randint", label: "np.random.randint()" },
  { key: "np.random.uniform", label: "np.random.uniform()" },
  { key: "np.random.normal", label: "np.random.normal()" },
];

function toNumber(value, label) {
  const number = Number(value);

  if (!Number.isFinite(number)) {
    throw new Error(`${label} must be a valid number.`);
  }

  return number;
}

function toInteger(value, label) {
  const number = Number(value);

  if (!Number.isInteger(number)) {
    throw new Error(`${label} must be a whole number.`);
  }

  return number;
}

function parseShape(value) {
  const cleaned = String(value ?? "")
    .trim()
    .replace(/[()[\]]/g, "");

  if (!cleaned) {
    throw new Error("Shape is required.");
  }

  const parts = cleaned
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);

  const shape = parts.map((part) => toInteger(part, "Shape"));

  if (!shape.length || shape.some((size) => size <= 0)) {
    throw new Error("Shape values must be positive integers.");
  }

  if (shape.length > 2) {
    throw new Error("The current visual playground supports 1D and 2D arrays.");
  }

  return shape;
}

function createFilledArray(shape, value) {
  if (shape.length === 1) {
    return Array.from({ length: shape[0] }, () => value);
  }

  const [rows, columns] = shape;

  return Array.from({ length: rows }, () =>
    Array.from({ length: columns }, () => value)
  );
}

function parseSource(source) {
  let parsed;

  try {
    parsed = JSON.parse(source);
  } catch {
    throw new Error("SOURCE ARRAY must be valid JSON array syntax.");
  }

  if (!Array.isArray(parsed) || parsed.length === 0) {
    throw new Error("SOURCE ARRAY must contain an array.");
  }

  const is2D = Array.isArray(parsed[0]);

  if (!is2D) {
    if (parsed.some((item) => Array.isArray(item))) {
      throw new Error("Invalid array structure.");
    }

    return parsed;
  }

  const columns = parsed[0].length;

  if (!columns) {
    throw new Error("Array rows cannot be empty.");
  }

  if (
    parsed.some(
      (row) => !Array.isArray(row) || row.length !== columns
    )
  ) {
    throw new Error("All rows must have the same number of columns.");
  }

  return parsed;
}

function parseValues(value) {
  const values = String(value ?? "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean)
    .map((item) => toNumber(item, "Values"));

  if (!values.length) {
    throw new Error("Values are required.");
  }

  return values;
}

function createArange(start, stop, step) {
  if (step === 0) {
    throw new Error("Step cannot be zero.");
  }

  const values = [];
  const maxItems = 10000;

  if (step > 0 && start >= stop) return values;
  if (step < 0 && start <= stop) return values;

  let current = start;
  let guard = 0;

  if (step > 0) {
    while (current < stop && guard < maxItems) {
      values.push(Number(current.toFixed(12)));
      current += step;
      guard += 1;
    }
  } else {
    while (current > stop && guard < maxItems) {
      values.push(Number(current.toFixed(12)));
      current += step;
      guard += 1;
    }
  }

  return values;
}

function createLinspace(start, stop, count) {
  if (count <= 0) {
    throw new Error("Count must be a positive integer.");
  }

  if (count === 1) return [start];

  const step = (stop - start) / (count - 1);

  return Array.from({ length: count }, (_, index) =>
    Number((start + index * step).toFixed(12))
  );
}

function randomValue(min, max) {
  return min + Math.random() * (max - min);
}

function createRandomArray(shape, generator) {
  if (shape.length === 1) {
    return Array.from({ length: shape[0] }, generator);
  }

  const [rows, columns] = shape;

  return Array.from({ length: rows }, () =>
    Array.from({ length: columns }, generator)
  );
}

function normalRandom(mean, stdDev) {
  let u = 0;
  let v = 0;

  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();

  const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  return mean + z * stdDev;
}

export function generateArray(functionName, params = {}) {
  switch (functionName) {
    case "np.array":
      return parseSource(params.source);

    case "np.zeros": {
      const shape = parseShape(params.shape);
      return createFilledArray(shape, 0);
    }

    case "np.ones": {
      const shape = parseShape(params.shape);
      return createFilledArray(shape, 1);
    }

    case "np.full": {
      const shape = parseShape(params.shape);
      const value = toNumber(params.fillValue, "Value");
      return createFilledArray(shape, value);
    }

    case "np.empty": {
      const shape = parseShape(params.shape);
      // JavaScript has no NumPy-style uninitialized memory. Zero is used
      // only as a stable visual placeholder for the playground.
      return createFilledArray(shape, 0);
    }

    case "np.arange": {
      const start = toNumber(params.start, "Start");
      const stop = toNumber(params.stop, "Stop");
      const step = toNumber(params.step, "Step");
      return createArange(start, stop, step);
    }

    case "np.linspace": {
      const start = toNumber(params.start, "Start");
      const stop = toNumber(params.stop, "Stop");
      const count = toInteger(params.count, "Count");
      return createLinspace(start, stop, count);
    }

    case "np.eye": {
      const size = toInteger(params.size, "Size");
      if (size <= 0) throw new Error("Size must be positive.");
      return Array.from({ length: size }, (_, row) =>
        Array.from({ length: size }, (_, column) =>
          row === column ? 1 : 0
        )
      );
    }

    case "np.identity": {
      const size = toInteger(params.size, "Size");
      if (size <= 0) throw new Error("Size must be positive.");
      return Array.from({ length: size }, (_, row) =>
        Array.from({ length: size }, (_, column) =>
          row === column ? 1 : 0
        )
      );
    }

    case "np.diag": {
      const values = parseValues(params.values);
      return values.map((value, row) =>
        values.map((_, column) => (row === column ? value : 0))
      );
    }

    case "np.random.random": {
      const shape = parseShape(params.shape);
      return createRandomArray(shape, () => Number(Math.random().toFixed(6)));
    }

    case "np.random.rand": {
      const shape = parseShape(params.shape);
      return createRandomArray(shape, () => Number(Math.random().toFixed(6)));
    }

    case "np.random.randn": {
      const shape = parseShape(params.shape);
      return createRandomArray(shape, () => Number(normalRandom(0, 1).toFixed(6)));
    }

    case "np.random.randint": {
      const low = toInteger(params.low, "Low");
      const high = toInteger(params.high, "High");
      const shape = parseShape(params.shape);

      if (high <= low) {
        throw new Error("High must be greater than Low.");
      }

      return createRandomArray(shape, () =>
        Math.floor(Math.random() * (high - low)) + low
      );
    }

    case "np.random.uniform": {
      const low = toNumber(params.low, "Low");
      const high = toNumber(params.high, "High");
      const shape = parseShape(params.shape);

      if (high <= low) {
        throw new Error("High must be greater than Low.");
      }

      return createRandomArray(shape, () =>
        Number(randomValue(low, high).toFixed(6))
      );
    }

    case "np.random.normal": {
      const loc = toNumber(params.loc, "Mean");
      const scale = toNumber(params.scale, "Std Dev");
      const shape = parseShape(params.shape);

      if (scale < 0) {
        throw new Error("Std Dev cannot be negative.");
      }

      return createRandomArray(shape, () =>
        Number(normalRandom(loc, scale).toFixed(6))
      );
    }

    default:
      throw new Error(`Unsupported array creation function: ${functionName}`);
  }
}

function formatShape(shapeValue) {
  const cleaned = String(shapeValue ?? "2, 3")
    .trim()
    .replace(/[()[\]]/g, "");

  const parts = cleaned
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);

  if (parts.length <= 1) {
    return parts[0] || "5";
  }

  return `(${parts.join(", ")})`;
}

function formatSource(source) {
  try {
    const parsed = JSON.parse(source);
    return JSON.stringify(parsed, null, 2);
  } catch {
    return source;
  }
}

export function buildArrayCreationCode(functionName, params = {}) {
  switch (functionName) {
    case "np.array":
      return `import numpy as np\n\narr = np.array(${formatSource(params.source)})`;

    case "np.zeros":
    case "np.ones":
    case "np.empty":
      return `import numpy as np\n\narr = ${functionName}(${formatShape(params.shape)})`;

    case "np.full":
      return `import numpy as np\n\narr = np.full(${formatShape(params.shape)}, ${params.fillValue || 7})`;

    case "np.arange":
      return `import numpy as np\n\narr = np.arange(${params.start || 0}, ${params.stop || 10}, ${params.step || 1})`;

    case "np.linspace":
      return `import numpy as np\n\narr = np.linspace(${params.start || 0}, ${params.stop || 1}, ${params.count || 5})`;

    case "np.eye":
      return `import numpy as np\n\narr = np.eye(${params.size || 3})`;

    case "np.identity":
      return `import numpy as np\n\narr = np.identity(${params.size || 3})`;

    case "np.diag":
      return `import numpy as np\n\narr = np.diag([${params.values || "1, 2, 3"}])`;

    case "np.random.random":
      return `import numpy as np\n\narr = np.random.random(${formatShape(params.shape)})`;

    case "np.random.rand":
    case "np.random.randn": {
      const shape = String(params.shape || "2, 3")
        .trim()
        .replace(/[()[\]]/g, "")
        .split(",")
        .map((part) => part.trim())
        .filter(Boolean);

      const args = shape.join(", ") || "5";
      return `import numpy as np\n\narr = ${functionName}(${args})`;
    }

    case "np.random.randint":
      return `import numpy as np\n\narr = np.random.randint(${params.low || 0}, ${params.high || 10}, ${formatShape(params.shape)})`;

    case "np.random.uniform":
      return `import numpy as np\n\narr = np.random.uniform(${params.low || 0}, ${params.high || 1}, ${formatShape(params.shape)})`;

    case "np.random.normal":
      return `import numpy as np\n\narr = np.random.normal(${params.loc || 0}, ${params.scale || 1}, ${formatShape(params.shape)})`;

    default:
      return "import numpy as np";
  }
}
